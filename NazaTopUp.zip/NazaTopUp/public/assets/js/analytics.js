// Fungsi untuk mengirim data halaman yang dikunjungi ke Google Analytics
function trackPageView(page) {
    if (window.ga) {  // Memeriksa apakah Google Analytics tersedia
        ga('send', 'pageview', page); // Mengirim data halaman ke Google Analytics
    }
}

// Fungsi untuk melacak interaksi tombol atau event lainnya
function trackEvent(category, action, label) {
    if (window.ga) {  // Memeriksa apakah Google Analytics tersedia
        ga('send', 'event', category, action, label); // Mengirim event ke Google Analytics
    }
}

// Fungsi untuk menginisialisasi Google Analytics dan melacak halaman yang dimuat
(function() {
    // Memastikan bahwa Google Analytics sudah terintegrasi dengan benar
    if (typeof window.ga === 'function') {
        // Men-track halaman pertama yang dimuat
        trackPageView(window.location.pathname);
    }

    // Menambahkan event listener untuk melacak klik pada tombol
    document.querySelectorAll('.track-button').forEach(function(button) {
        button.addEventListener('click', function() {
            trackEvent('Button', 'Click', button.innerText); // Men-track klik tombol
        });
    });

})();
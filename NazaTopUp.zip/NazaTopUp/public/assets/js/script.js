// Menambahkan alert saat halaman dimuat
window.onload = function() {
    console.log("Welcome to Top-Up Store!");
    alert("Welcome to Top-Up Store! Start exploring our products.");
};
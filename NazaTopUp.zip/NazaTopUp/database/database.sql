CREATE DATABASE topup_store;

USE topup_store;

CREATE TABLE transactions (
  id INT PRIMARY KEY AUTO_INCREMENT,
  game_id VARCHAR(50),
  amount INT,
  payment_method VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(50),
  password VARCHAR(255),
  email VARCHAR(100)
);
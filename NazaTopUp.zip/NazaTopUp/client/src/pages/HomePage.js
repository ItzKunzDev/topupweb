import React from 'react';

const HomePage = () => {
  return (
    <div className="home-page">
      <h1>Welcome to the Top-Up Store</h1>
      <p>Find the best top-up offers here!</p>
    </div>
  );
};

export default HomePage;
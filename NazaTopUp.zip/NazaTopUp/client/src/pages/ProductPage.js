import React from 'react';
import ProductCard from '../components/ProductCard';

const ProductsPage = () => {
  return (
    <div className="products-page">
      <h2>Our Products</h2>
      <div className="product-list">
        {/* Misalnya menampilkan beberapa produk dengan komponen ProductCard */}
        <ProductCard product={{ name: 'Game A', price: '$10' }} />
        <ProductCard product={{ name: 'Game B', price: '$15' }} />
      </div>
    </div>
  );
};

export default ProductsPage;
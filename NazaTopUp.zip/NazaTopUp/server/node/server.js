const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const products = [
  { id: 1, name: "Mobile Legends Diamonds", price: 50000 },
  { id: 2, name: "Free Fire Diamonds", price: 45000 },
  { id: 3, name: "PUBG UC", price: 60000 },
];

app.get('/products', (req, res) => {
  res.json(products);
});

app.post('/payment', (req, res) => {
  const { gameId, amount } = req.body;
  if (!gameId || !amount) {
    return res.status(400).json({ status: "error", message: "Data tidak lengkap." });
  }
  res.json({ status: "success", message: "Pembayaran berhasil!", gameId, amount });
});

app.listen(3000, () => {
  console.log('Server berjalan di http://localhost:3000');
});
<?php
// Konfigurasi untuk koneksi database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'password'); // Ganti dengan password database Anda
define('DB_NAME', 'topup_store');

// Menghubungkan ke database
function getDbConnection() {
    try {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME;
        $pdo = new PDO($dsn, DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        die('Connection failed: ' . $e->getMessage());
    }
}

// Pengaturan API, seperti kunci API untuk pembayaran Midtrans
define('MIDTRANS_SERVER_KEY', 'your-midtrans-server-key'); // Ganti dengan server key Midtrans Anda
define('MIDTRANS_CLIENT_KEY', 'your-midtrans-client-key'); // Ganti dengan client key Midtrans Anda

// Pengaturan dasar lainnya
define('SITE_NAME', 'Naza TopUp');
define('SITE_URL', 'https://www.topupstore.com');

// Fungsi untuk menampilkan pesan error
function displayError($message) {
    echo json_encode(['status' => 'error', 'message' => $message]);
}

// Fungsi untuk menampilkan pesan sukses
function displaySuccess($message) {
    echo json_encode(['status' => 'success', 'message' => $message]);
}
?>
<?php
require 'config.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $gameId = $_POST['gameId'];
    $amount = $_POST['amount'];
    $paymentMethod = $_POST['paymentMethod'];

    if (empty($gameId) || empty($amount)) {
        echo json_encode(["status" => "error", "message" => "Data tidak lengkap."]);
        exit();
    }

    // Simulasi pembayaran sukses
    echo json_encode(["status" => "success", "message" => "Pembayaran berhasil!", "gameId" => $gameId, "amount" => $amount]);
    exit();
}
?>
<?php
header("Content-Type: application/json");

// Simulasi data produk
$products = [
    ["id" => 1, "name" => "Mobile Legends Diamonds", "price" => 50000],
    ["id" => 2, "name" => "Free Fire Diamonds", "price" => 45000],
    ["id" => 3, "name" => "PUBG UC", "price" => 60000]
];

// Mengembalikan data produk sebagai JSON
echo json_encode($products);
?>
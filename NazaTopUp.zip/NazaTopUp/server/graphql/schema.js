const { GraphQLObjectType, GraphQLSchema, GraphQLString, GraphQLInt, GraphQLFloat, GraphQLList } = require('graphql');
const { ProductType, TransactionType, UserType } = require('./types'); // Mendefinisikan tipe untuk produk, transaksi, dan pengguna
const ProductController = require('../controllers/ProductController');
const TransactionController = require('../controllers/TransactionController');

// Definisikan query untuk GraphQL
const RootQuery = new GraphQLObjectType({
  name: 'RootQueryType',
  fields: {
    // Query untuk mendapatkan daftar produk
    products: {
      type: new GraphQLList(ProductType),
      resolve(parent, args) {
        return ProductController.getAllProducts(); // Mendapatkan semua produk
      },
    },
    // Query untuk mendapatkan detail produk berdasarkan ID
    product: {
      type: ProductType,
      args: {
        id: { type: GraphQLInt },
      },
      resolve(parent, args) {
        return ProductController.getProductById(args.id); // Mendapatkan produk berdasarkan ID
      },
    },
    // Query untuk mendapatkan transaksi berdasarkan ID pengguna
    transactions: {
      type: new GraphQLList(TransactionType),
      args: {
        userId: { type: GraphQLInt },
      },
      resolve(parent, args) {
        return TransactionController.getTransactionsByUser(args.userId); // Mendapatkan transaksi berdasarkan ID pengguna
      },
    },
    // Query untuk mendapatkan detail transaksi berdasarkan ID transaksi
    transaction: {
      type: TransactionType,
      args: {
        id: { type: GraphQLInt },
      },
      resolve(parent, args) {
        return TransactionController.getTransactionById(args.id); // Mendapatkan transaksi berdasarkan ID
      },
    },
  },
});

// Definisikan mutasi untuk GraphQL
const Mutation = new GraphQLObjectType({
  name: 'Mutation',
  fields: {
    // Mutasi untuk membuat produk baru
    addProduct: {
      type: ProductType,
      args: {
        name: { type: GraphQLString },
        description: { type: GraphQLString },
        price: { type: GraphQLFloat },
      },
      resolve(parent, args) {
        return ProductController.createProduct(args); // Membuat produk baru
      },
    },
    // Mutasi untuk membuat transaksi baru
    addTransaction: {
      type: TransactionType,
      args: {
        userId: { type: GraphQLInt },
        amount: { type: GraphQLFloat },
        status: { type: GraphQLString },
        transactionId: { type: GraphQLString },
      },
      resolve(parent, args) {
        return TransactionController.createTransaction(args); // Membuat transaksi baru
      },
    },
  },
});

// Membuat schema GraphQL
const schema = new GraphQLSchema({
  query: RootQuery,
  mutation: Mutation,
});

module.exports = schema;
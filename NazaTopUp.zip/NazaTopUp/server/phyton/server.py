from flask import Flask, jsonify, request

app = Flask(__name__)

# Simulasi database produk
products = [
    {"id": 1, "name": "Mobile Legends Diamonds", "price": 50000},
    {"id": 2, "name": "Free Fire Diamonds", "price": 45000},
    {"id": 3, "name": "PUBG UC", "price": 60000}
]

@app.route('/products', methods=['GET'])
def get_products():
    return jsonify(products)

@app.route('/payment', methods=['POST'])
def payment():
    data = request.get_json()
    gameId = data.get('gameId')
    amount = data.get('amount')

    if not gameId or not amount:
        return jsonify({"status": "error", "message": "Data tidak lengkap."}), 400

    return jsonify({"status": "success", "message": "Pembayaran berhasil!", "gameId": gameId, "amount": amount})

if __name__ == '__main__':
    app.run(debug=True)
<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TopUpController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\OrderController;

// Rute untuk otentikasi pengguna
Route::post('/login', [AuthController::class, 'login']);
Route::post('/register', [AuthController::class, 'register']);
Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth:api');

// Rute untuk produk
Route::get('/products', [ProductController::class, 'index']); // Mendapatkan daftar produk
Route::get('/products/{id}', [ProductController::class, 'show']); // Mendapatkan detail produk

// Rute untuk pembayaran
Route::post('/payment/create', [PaymentController::class, 'createPayment']); // Membuat permintaan pembayaran
Route::post('/payment/callback', [PaymentController::class, 'paymentCallback']); // Callback pembayaran dari Midtrans

// Rute untuk top-up
Route::post('/topup', [TopUpController::class, 'topUp'])->middleware('auth:api'); // Top-up akun pengguna

// Rute untuk pesanan
Route::get('/orders', [OrderController::class, 'index'])->middleware('auth:api'); // Mendapatkan daftar pesanan
Route::get('/orders/{id}', [OrderController::class, 'show'])->middleware('auth:api'); // Mendapatkan detail pesanan
Route::post('/orders', [OrderController::class, 'store'])->middleware('auth:api'); // Membuat pesanan baru

// Rute default untuk tes API
Route::get('/test', function () {
    return response()->json(['message' => 'API is working'], 200);
});
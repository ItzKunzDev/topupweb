<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTransactionTable extends Migration
{
    /**
     * Jalankan migrasi untuk membuat tabel transaksi.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transactions', function (Blueprint $table) {
            $table->id(); // ID transaksi
            $table->unsignedBigInteger('user_id'); // ID pengguna yang melakukan transaksi
            $table->decimal('amount', 12, 2); // Jumlah transaksi
            $table->string('status'); // Status transaksi (pending, success, failed)
            $table->string('payment_method')->nullable(); // Metode pembayaran (misalnya Midtrans, PayPal, dll.)
            $table->string('transaction_id')->unique(); // ID unik transaksi (dari Midtrans atau sistem lain)
            $table->string('payment_url')->nullable(); // URL pembayaran (misalnya URL untuk pembayaran Midtrans)
            $table->timestamp('created_at')->useCurrent(); // Tanggal dan waktu transaksi dibuat
            $table->timestamp('updated_at')->useCurrent()->nullable(); // Tanggal dan waktu transaksi diperbarui
            $table->timestamp('paid_at')->nullable(); // Waktu transaksi dibayar (untuk pembayaran yang berhasil)

            // Menambahkan foreign key constraint untuk `user_id` yang mengarah ke tabel `users`
            $table->foreign('user_id')->references('id')->on
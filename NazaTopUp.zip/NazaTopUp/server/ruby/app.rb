require 'sinatra'
require 'json'

products = [
  { id: 1, name: 'Mobile Legends Diamonds', price: 50000 },
  { id: 2, name: 'Free Fire Diamonds', price: 45000 },
  { id: 3, name: 'PUBG UC', price: 60000 }
]

# Endpoint Produk
get '/products' do
  content_type :json
  products.to_json
end

# Endpoint Pembayaran
post '/payment' do
  data = JSON.parse(request.body.read)
  game_id = data['gameId']
  amount = data['amount']

  if game_id.nil? || amount.nil?
    status 400
    { status: 'error', message: 'Data tidak lengkap.' }.to_json
  else
    { status: 'success', message: 'Pembayaran berhasil!', gameId: game_id, amount: amount }.to_json
  end
end